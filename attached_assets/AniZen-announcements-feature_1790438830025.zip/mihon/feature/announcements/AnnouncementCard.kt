package mihon.feature.announcements

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage

@Composable
fun AnnouncementCard(entry: AnnouncementEntry, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            AsyncImage(
                model = entry.coverImageUrl,
                contentDescription = entry.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(width = 90.dp, height = 130.dp)
                    .clip(RoundedCornerShape(8.dp)),
            )
            Column(modifier = Modifier.padding(start = 12.dp)) {
                CategoryBadge(category = entry.category)
                Text(
                    text = entry.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text(
                    text = entry.description,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text(
                    text = expectedOrCountdownText(entry),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun CategoryBadge(category: AnnouncementCategory) {
    val (backgroundColor, label) = when (category) {
        AnnouncementCategory.ADAPTATION -> Color(0xFF2D6CDF) to "Adaptation"
        AnnouncementCategory.SEQUEL -> Color(0xFF3FA34D) to "Sequel"
        AnnouncementCategory.NEW_SEASON -> Color(0xFFC98A1F) to "New Season"
        AnnouncementCategory.MOVIE -> Color(0xFFD23B6E) to "Movie"
    }
    Surface(color = backgroundColor, shape = RoundedCornerShape(50)) {
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

/**
 * Static text computed at render/recomposition time — not a live-ticking
 * countdown. Wire a ticking version with LaunchedEffect + delay() if a
 * live-updating timer like the mockup's is required; keeping this static
 * keeps a scrolling list of cards cheap.
 *
 * Accuracy note: [AnnouncementEntry.exactReleaseDate] is midnight UTC of
 * whatever date AniList has on file — AniList's `startDate` field is
 * year/month/day only, with no time component. The day/hour/minute
 * breakdown below is real arithmetic against that timestamp, but it is
 * time-until-AniList's-date, not a countdown to an actual confirmed
 * broadcast time (which AniList doesn't provide). Kept at this
 * granularity because the requested design shows it this way; just don't
 * present it anywhere as an exact release-time countdown.
 */
fun expectedOrCountdownText(entry: AnnouncementEntry): String {
    val exact = entry.exactReleaseDate
    if (exact == null) {
        return entry.expectedYear?.let { "Expected $it" } ?: ""
    }
    val remaining = exact - System.currentTimeMillis()
    if (remaining <= 0) return "Releasing now"
    val days = remaining / (24 * 60 * 60 * 1000)
    val hours = (remaining / (60 * 60 * 1000)) % 24
    val minutes = (remaining / (60 * 1000)) % 60
    return "${days}d ${hours}h ${minutes}m"
}
