package mihon.feature.announcements

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

// Plain enum — kotlin-parcelize supports enums natively, no annotation needed here.
@Serializable
enum class AnnouncementCategory {
    ADAPTATION,
    SEQUEL,
    NEW_SEASON,
    MOVIE,
}

// Both @Serializable (for the JSON disk cache) and @Parcelize/Parcelable
// (so AnnouncementDetailScreen can carry a full entry across navigation
// without a separate repository lookup). Both annotations on one class is
// a standard, supported combination in Kotlin.
@Serializable
@Parcelize
data class AnnouncementEntry(
    val aniListMediaId: Int,
    val title: String,
    val category: AnnouncementCategory,
    val description: String,
    val expectedYear: Int?,
    val relatedAniListMediaId: Int?,
    val relatedTitle: String?,
    val relatedYear: Int?,
    val coverImageUrl: String?, // sourced from coverImage.extraLarge — the highest-res tier AniList serves
    val bannerImageUrl: String?, // for the detail screen header only
    val exactReleaseDate: Long?, // epoch millis at 00:00 UTC of AniList's confirmed date — see AnnouncementCard.kt's doc comment on what this does and doesn't mean
    val fetchedFrom: String, // "AniList API" or "MAL (Jikan, fallback)" — debugging/logs only, never shown in UI
) : Parcelable
