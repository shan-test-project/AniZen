# Wiring these files into AniZen

Everything below is what's needed to make the 12 files in this folder
actually reachable from the app.

## Fixed since the last pass (no longer open items)

- `AnnouncementEntry` is now both `@Serializable` (disk cache) and
  `@Parcelize`/`Parcelable` (screen navigation) — `AnnouncementDetailScreen`
  compiles as a `@Parcelize` Screen without changes needed.
- Notification channel is now created (`AnnouncementNotifications.ensureChannel`)
  and a small icon is set, instead of being left unregistered/unset.
- Related Anime tap now navigates to the app's global search screen with
  the related title as the query, instead of being a no-op.
- Pagination: `AnnouncementsApi.fetchAnnouncements()` now fetches up to 4
  pages (configurable) and dedupes by id, instead of only ever seeing the
  first 25 results.
- `NEW_SEASON` can now actually be produced — `categoryFor()` distinguishes
  it from `SEQUEL` via a title-overlap heuristic (see the doc comment on
  `AnnouncementTextBuilder.categoryFor` — this is disclosed as a heuristic,
  not a guaranteed-correct classification, since AniList has no field that
  cleanly separates "next season of the same franchise" from "distinct
  sequel title").
- The fallback path (`AnnouncementsScraper.kt`) has been replaced with
  `AnnouncementsFallbackApi.kt`, which calls MyAnimeList's Jikan
  `/seasons/upcoming` endpoint instead of attempting to scrape AniList's
  HTML. AniList's site is a client-rendered Vue.js SPA — a plain HTTP GET
  cannot see any anime data, since it only exists after client-side JS
  runs. The old scraper would have silently returned an empty list every
  single time it ran. If a literal AniList-only fallback is a hard
  requirement, the only viable version of that is retrying AniList's own
  API with backoff, not scraping the site.
- Countdown text (`AnnouncementCard.kt`) now has a doc comment clarifying
  it's time-until-AniList's-date (midnight UTC of a year/month/day value),
  not a countdown to a confirmed broadcast time — AniList doesn't provide
  time-of-day data, so no display format could show a truly "exact" time
  regardless. The day/hour/minute granularity itself is kept as-is since
  it matches the originally requested design.

## Still required — DI, tab registration, resources

### 1. Register `AnnouncementsPreferences` in DI
Mirror wherever `SchedulePreferences` gets registered with Injekt.

### 2. Add the tab to `BrowseTab.kt`
```kotlin
add(
    eu.kanade.presentation.components.TabContent(
        titleRes = /* add a string resource, e.g. MR.strings.label_announcements */,
        searchEnabled = false,
        content = { contentPadding, _ ->
            mihon.feature.announcements.AnnouncementsTab.Content(contentPadding)
        },
    ),
)
```

### 3. Confirm resource names
- `R.drawable.ic_notification` in `AnnouncementNotifications.kt` — verify
  this drawable actually exists in this app; swap if it uses a different
  name for notification icons.
- The exact `NotificationManagerCompat.createNotificationChannel(...)`
  overload — flagged inline in `AnnouncementNotifications.kt`; mirror
  whatever `ScheduleNotifications.kt`'s own channel setup already does
  rather than guessing between `NotificationChannel` and
  `NotificationChannelCompat`.

### 4. Confirm `GlobalSearchScreen`'s exact package
`AnnouncementDetailScreen.kt` references
`eu.kanade.tachiyomi.ui.browse.source.globalsearch.GlobalSearchScreen(query)`
— this package path is inferred from this project's earlier fix history,
not directly re-confirmed in this pass. Verify before compiling.

### 5. Confirm `PreferenceStore.getStringSet(...)`
Used in `AnnouncementsPreferences.kt` for the watchlist/notified-ids sets —
confirmed against `SchedulePreferences.notifySeriesMediaIds()`'s existing
usage pattern, but check the exact method name on this app's
`PreferenceStore` interface.

## Not required for v1
- No new WorkManager job — the watchlist release-date check piggybacks on
  whatever already triggers `AnnouncementsRepository.getAnnouncements()`.
- No AndroidManifest changes — no new Activity/Service.
