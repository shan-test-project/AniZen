package mihon.feature.announcements

import eu.kanade.tachiyomi.network.NetworkHelper
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import logcat.LogPriority
import okhttp3.Request
import tachiyomi.core.common.util.system.logcat
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Fallback used ONLY when [AnnouncementsApi] throws or AniList rate-limits
 * the request.
 *
 * NOTE — this is NOT scraping AniList's website, on purpose. AniList's site
 * is a client-rendered Vue.js single-page app: a plain HTTP GET returns
 * shell HTML with no anime data in it, since the actual content only
 * exists after client-side JS executes. This is exactly why essentially
 * every third-party AniList tool in the ecosystem consumes the GraphQL API
 * rather than scraping the site — there's nothing server-rendered to
 * scrape. A prior version of this file attempted HTML scraping anyway and
 * would have silently returned an empty list every time it ran.
 *
 * Instead, this fallback uses MyAnimeList's public Jikan API
 * (https://docs.api.jikan.moe), specifically `/seasons/upcoming` — a real,
 * structured, unauthenticated JSON endpoint, matching the same
 * AniList-primary/MAL-fallback pattern already established elsewhere in
 * this project (see the relations/character-card fallback spec). If a
 * literal AniList-only fallback is a hard requirement, the only viable
 * version of that would be retrying AniList's own API with backoff — not
 * scraping its site.
 */
class AnnouncementsFallbackApi(
    private val networkHelper: NetworkHelper = Injekt.get(),
    private val json: Json = Injekt.get(),
) {
    fun fetchAnnouncements(): List<AnnouncementEntry> {
        return try {
            fetchInternal()
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "AnnouncementsFallbackApi: Jikan fetch failed, returning empty list" }
            emptyList()
        }
    }

    private fun fetchInternal(): List<AnnouncementEntry> {
        val request = Request.Builder()
            .url("https://api.jikan.moe/v4/seasons/upcoming")
            .build()

        val body = networkHelper.client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            response.body.string()
        }

        val parsed = json.decodeFromString<JikanUpcomingResponse>(body)
        return parsed.data.mapNotNull { it.toAnnouncementEntry() }
    }

    private fun JikanAnimeDto.toAnnouncementEntry(): AnnouncementEntry? {
        val titleText = title ?: return null
        // Jikan's /seasons/upcoming doesn't expose prequel/sequel relation
        // edges or source material as cheaply as AniList's single query
        // does (that would need a second call per entry), so this path
        // can't categorize as precisely as the primary API path.
        // Defaulting to ADAPTATION is a deliberate simplification for the
        // fallback case, not a claim about the actual content.
        val category = AnnouncementCategory.ADAPTATION
        return AnnouncementEntry(
            aniListMediaId = malId, // NOTE: this is a MAL id, not an AniList id, despite the field name — see WIRING.md
            title = titleText,
            category = category,
            description = AnnouncementTextBuilder.buildDescription(
                title = titleText,
                category = category,
                format = type,
                source = null,
                relatedTitle = null,
                relatedYear = null,
                expectedYear = null,
            ),
            expectedYear = null,
            relatedAniListMediaId = null,
            relatedTitle = null,
            relatedYear = null,
            coverImageUrl = images?.jpg?.largeImageUrl ?: images?.jpg?.imageUrl,
            bannerImageUrl = null,
            exactReleaseDate = null,
            fetchedFrom = "MAL (Jikan, fallback)",
        )
    }
}

@Serializable
private data class JikanUpcomingResponse(val data: List<JikanAnimeDto> = emptyList())

@Serializable
private data class JikanAnimeDto(
    @SerialName("mal_id") val malId: Int,
    val title: String? = null,
    val type: String? = null,
    val images: JikanImagesDto? = null,
)

@Serializable
private data class JikanImagesDto(val jpg: JikanJpgDto? = null)

@Serializable
private data class JikanJpgDto(
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("large_image_url") val largeImageUrl: String? = null,
)
