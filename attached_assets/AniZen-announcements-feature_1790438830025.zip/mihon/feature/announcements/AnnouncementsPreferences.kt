package mihon.feature.announcements

import tachiyomi.core.common.preference.PreferenceStore

/**
 * Register this class in the app's Injekt module the same way
 * SchedulePreferences is registered (mirror that exact registration line —
 * see mihon/feature/airingschedule/SchedulePreferences.kt's DI wiring),
 * otherwise Injekt.get<AnnouncementsPreferences>() defaults elsewhere in
 * this feature will fail to resolve.
 */
class AnnouncementsPreferences(private val preferenceStore: PreferenceStore) {

    /** Single cache blob for the whole "All" list; category filtering happens client-side over it. */
    fun cacheBlob() = preferenceStore.getString("announcements_cache_all", "")

    fun lastFetchedAt() = preferenceStore.getLong("announcements_last_fetched_all", 0L)

    /**
     * AniList media ids the user has watchlisted for a release-date-confirmed
     * notification. Verify the exact method name PreferenceStore uses for a
     * Set<String>-backed preference against SchedulePreferences.kt's
     * notifySeriesMediaIds() — it's assumed to be getStringSet below, matching
     * that existing usage, but confirm before compiling.
     */
    fun watchlistMediaIds() = preferenceStore.getStringSet("announcement_watchlist_media_ids", emptySet())

    /** Tracks which watchlisted ids have already fired their one-time notification, so it never repeats. */
    fun notifiedReleaseDateMediaIds() = preferenceStore.getStringSet("announcement_notified_release_date_ids", emptySet())
}
