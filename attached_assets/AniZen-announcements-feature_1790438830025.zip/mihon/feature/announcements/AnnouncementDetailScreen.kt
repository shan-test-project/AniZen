package mihon.feature.announcements

import android.os.Parcelable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import coil3.compose.AsyncImage
import kotlinx.parcelize.Parcelize

@Parcelize
data class AnnouncementDetailScreen(private val entry: AnnouncementEntry) : Screen, Parcelable {

    @Composable
    override fun Content() {
        // Lightweight — just the repository, not the full list ScreenModel,
        // so opening this screen never triggers a redundant network fetch.
        val repository = remember { AnnouncementsRepository() }
        var isWatchlisted by remember { mutableStateOf(repository.isWatchlisted(entry.aniListMediaId)) }
        val navigator = LocalNavigator.currentOrThrow

        Scaffold { contentPadding ->
            Column(
                modifier = Modifier
                    .padding(contentPadding)
                    .verticalScroll(rememberScrollState())
                    .fillMaxWidth(),
            ) {
                AsyncImage(
                    model = entry.bannerImageUrl ?: entry.coverImageUrl,
                    contentDescription = entry.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(180.dp),
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = entry.title, style = MaterialTheme.typography.headlineSmall)
                    Text(
                        text = entry.description,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp),
                    )

                    Row(
                        modifier = Modifier.padding(top = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                    ) {
                        entry.expectedYear?.let { year ->
                            LabeledValue(label = "Expected", value = year.toString())
                        }
                        LabeledValue(label = "Source", value = "AniList")
                    }

                    if (entry.relatedAniListMediaId != null && entry.relatedTitle != null) {
                        Text(
                            text = "Related Anime",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
                        )
                        RelatedAnimeCard(
                            title = entry.relatedTitle,
                            year = entry.relatedYear,
                            onClick = {
                                // No "current source" context exists here (unlike
                                // the anime detail screen's own Prequel/Sequel tap
                                // handler, which searches within the anime's own
                                // extension) — this is the Browse tab, not bound to
                                // any single source. A global multi-source search is
                                // the correct behavior here, matching how this app's
                                // relation-tap fallback already works when no
                                // current-source context is available.
                                // VERIFY the exact package/class name below — this is
                                // the same GlobalSearchScreen(query) referenced
                                // conceptually earlier in this project's fix history
                                // (performSearch(navigator, query, global=true)), but
                                // its exact location hasn't been directly confirmed
                                // in this session.
                                navigator.push(
                                    eu.kanade.tachiyomi.ui.browse.source.globalsearch.GlobalSearchScreen(entry.relatedTitle),
                                )
                            },
                        )
                    }

                    Button(
                        onClick = {
                            repository.toggleWatchlist(entry.aniListMediaId)
                            isWatchlisted = !isWatchlisted
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                    ) {
                        Icon(
                            imageVector = if (isWatchlisted) Icons.Filled.NotificationsActive else Icons.Filled.Notifications,
                            contentDescription = null,
                        )
                        Text(
                            text = if (isWatchlisted) "Watching for Release Date" else "Add to Watchlist",
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }
        }
    }

    @Composable
    private fun LabeledValue(label: String, value: String) {
        Column {
            Text(text = label, style = MaterialTheme.typography.labelSmall)
            Text(text = value, style = MaterialTheme.typography.bodyMedium)
        }
    }

    @Composable
    private fun RelatedAnimeCard(title: String, year: Int?, onClick: () -> Unit) {
        Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = title, style = MaterialTheme.typography.bodyLarge)
                if (year != null) {
                    Text(text = year.toString(), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
