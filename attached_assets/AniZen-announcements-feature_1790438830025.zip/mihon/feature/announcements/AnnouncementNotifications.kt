package mihon.feature.announcements

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import eu.kanade.tachiyomi.R
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Fires exactly once per watchlisted anime, the first time its exact
 * release date becomes known.
 *
 * Verify Context resolution: assumes Injekt.get<Context>() works in this
 * app (some manager classes elsewhere take Context as an explicit
 * constructor param instead of a default — match whichever convention this
 * repo actually uses).
 *
 * Verify R.drawable.ic_notification exists — this is the icon name already
 * assumed for notifications elsewhere in this feature set's sibling spec
 * (the AI-assistant fix file); if this app uses a different resource name,
 * update SMALL_ICON_RES below to match rather than leaving it unset, since
 * a missing small icon is a real functional bug, not a cosmetic one.
 */
object AnnouncementNotifications {
    private const val CHANNEL_ID = "announcements_release_date"
    private const val NOTIFICATION_ID_BASE = 90_000 // offset clear of other notification ID ranges in this app
    private val SMALL_ICON_RES = R.drawable.ic_notification

    private var channelEnsured = false

    private fun ensureChannel(context: Context) {
        if (channelEnsured) return
        // NotificationManagerCompat.createNotificationChannel()'s expected
        // parameter type has changed across AndroidX core versions (some
        // take a raw android.app.NotificationChannel, newer ones take
        // NotificationChannelCompat). If this doesn't compile as-is, swap
        // to android.app.NotificationManager.createNotificationChannel()
        // directly (requires Build.VERSION.SDK_INT >= 26, which every
        // notification-related class in this app almost certainly already
        // assumes) or NotificationChannelCompat.Builder, whichever this
        // repo's other notification channels already use — check
        // ScheduleNotifications.kt's own channel setup and mirror it
        // exactly instead of guessing between these here.
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Announcement release dates",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
            description = "Notifies when a watchlisted announcement gets a confirmed release date"
        }
        NotificationManagerCompat.from(context).createNotificationChannel(channel)
        channelEnsured = true
    }

    fun notifyReleaseDateConfirmed(entry: AnnouncementEntry, context: Context = Injekt.get()) {
        ensureChannel(context)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("${entry.title} — release date confirmed")
            .setContentText(entry.description)
            .setSmallIcon(SMALL_ICON_RES)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(
            NOTIFICATION_ID_BASE + entry.aniListMediaId,
            notification,
        )
    }
}
